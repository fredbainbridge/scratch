﻿
# comment based help has been removed after generating external help
Function Get-ServerInfo {

    [cmdletbinding()]
    [outputType("PSServerinfo")]
    [alias("gsvi")]
    Param (
        [Parameter(
            Position = 0,
            HelpMessage = "Enter the name of a Windows computer.",
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
            )]
        [Alias("server", "cn")]
        [ValidateNotNullOrEmpty()]
        [string[]]$Computername = $env:computername,

        [ValidateRange(1, 10)]
        [int32]$Timeout
    )

    Begin {
        Write-Verbose "[BEGIN] Starting $($MyInvocation.MyCommand)"

        #define a hashtable of parameter values to splat to Get-CimInstance
        $cimParams = @{
            Classname    = "win32_Operatingsystem"
            ErrorAction  = "Stop"
            Computername = ""
        }

        if ($timeout) {
            Write-Verbose "[BEGIN] Adding timeout value of $timeout"
            $cimParams.add("OperationTimeOutSec", $Timeout)
        }
    } #begin

    Process {

        foreach ($computer in $computername) {

            Write-Verbose "[PROCESS] Processing computer: $($computer.toUpper())"

            $cimParams.computername = $computer

            Try {
                $os = Get-CimInstance @cimparams

                #moved this to the Try block so if there
                #is an error querying win32_computersystem, the same
                #catch block will be used
                if ($os) {
                    Write-Verbose "[PROCESS] Getting Computersystem info"

                    $csparams = @{
                        Classname    = "win32_computersystem"
                        computername = $os.csname
                        Property     = 'NumberOfProcessors', 'NumberOfLogicalProcessors'
                        ErrorAction  = 'Stop'
                    }

                    if ($timeout) {
                        $csParams.add("OperationTimeOutSec", $Timeout)
                    }

                    $cs = Get-CimInstance @csparams

                    Write-Verbose "[PROCESS] Creating output object"
                    [PSCustomobject]@{
                        PSTypename         = "PSServerInfo"
                        Operatingsystem    = $os.caption
                        Version            = $os.version
                        Uptime             = (Get-Date) - $os.lastbootuptime
                        MemoryGB           = $os.totalvisiblememorysize / 1MB -as [int32]
                        PhysicalProcessors = $cs.NumberOfProcessors
                        LogicalProcessors  = $cs.NumberOfLogicalProcessors
                        ComputerName       = $os.CSName
                    }

                } #if
            }
            Catch {
                #variation on warning message
                $msg = "Failed to contact $($computer.ToUpper()). $($_.exception.message)"

                Write-Warning $msg

            }

        } #foreach
    } #process
    End {
        Write-Verbose "[END] Exiting $($MyInvocation.MyCommand)"
    }

} #end Get-ServerInfo

