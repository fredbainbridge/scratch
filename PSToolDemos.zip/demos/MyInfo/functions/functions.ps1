
Function Get-HWInfo {
    #this is demo function that doesn't really do anything
    [cmdletbinding()]
    Param(
        [Parameter(Position = 0, Mandatory,HelpMessage = "Enter the name of a managed computer")]
        [ArgumentCompleter({$DomainComputers})]
        [string]$Computername,
        [Parameter(HelpMessage = "Enter an optional alternate credential.")]
        [pscredential]$Credential
        )
    #call the helper function
    $data = _DoFoo

    [pscustomobject]@{
        Name    = $computername.toUpper()
        Version = $data.version
        OS      = "Windows Unicorn"
        FreeGB  = $data.size
    }
}

Function Get-VolumeReport {
    [cmdletbinding(DefaultParameterSetName = "computer")]
    Param(
        [Parameter(Mandatory, ValueFromPipeline, ParameterSetName = "session")]
        [ValidateNotNullorEmpty()]
        [Microsoft.Management.Infrastructure.CimSession[]]$Cimsession,
        [Parameter(Position = 0, ValueFromPipeline,ValueFromPipelineByPropertyName,
         HelpMessage = "Enter a computername", ParameterSetName = "computer")]
        [ValidateNotNullorEmpty()]
        [string]$Computername = $env:computername,
        [Parameter(HelpMessage = "Enter a drive letter like C or D without the colon.")]
        [ValidatePattern("[c-zC-Z")]
        [string]$Drive = "C"
    )

    Begin {
        Write-Verbose "[BEGIN] Starting $($myinvocation.MyCommand)"
    }
    Process {
        if ($pscmdlet.ParameterSetName -eq "computer") {
            Write-Verbose "[PROCESS] Creating a temporary CimSession to $($Computername.toUpper())"
            Try {
            $Cimsession = New-CimSession -ComputerName $computername -ErrorAction Stop
            #set a flag to indicate this session was created here
            #so PowerShell can clean up
            $tempsession = $True
            }
            Catch {
                Write-Warning "Failed to create a CIMSession to $($Computername.toUpper()). $($_.exception.message)"
                #bail out
                return
            }
        }

        $params = @{
            Erroraction = "Stop"
            driveletter = $Drive.toUpper()
            CimSession  = $Cimsession
        }
        Write-Verbose "[PROCESS] Getting volume information for drive $Drive on $(($cimsession.computername).toUpper())"

        Get-Volume @params |
            Select-Object Driveletter, Size, SizeRemaining, HealthStatus,
        @{Name = "Date"; Expression = {(Get-Date)}},
        @{Name = "Computername"; Expression = {$_.pscomputername.toUpper()}}

        if ($tempsession) {
            Write-Verbose "[PROCESS] Removing temporary CimSession"
            Remove-CimSession -CimSession $Cimsession
        }
    } #process
    End {
        Write-Verbose "[END] Ending $($myinvocation.MyCommand)"

    }
} #close Get-VolumeReport

# private helper function that won't be exported
Function _DoFoo {
    [pscustomobject]@{
        size    = [math]::Round((Get-Random -Minimum 1gb -Maximum 10gb) / 1GB, 2)
        Version = "v{0}.0.0" -f (Get-Random -Minimum 2 -Maximum 6)
    }
}
