﻿#requires -version 5.1

# get server information for the help desk

Param ([string]$Computername = $env:ComputerName)

Write-Host "Getting server information for $Computername" -ForegroundColor Cyan

Get-CimInstance -classname win32_operatingsystem -ComputerName $computername |
Select-Object -Property Caption, Version,
@{Name = "Uptime"; Expression = { (Get-Date) - $_.lastbootuptime } },
@{Name = "MemoryGB"; Expression = { $_.totalvisiblememorysize / 1MB -as [int32] } },
@{Name = "PhysicalProcessors"; Expression = { (Get-CimInstance -classname win32_computersystem -ComputerName $computername -Property NumberOfProcessors).NumberOfProcessors } },
@{Name = "LogicalProcessors"; Expression = { (Get-CimInstance -classname win32_computersystem -ComputerName $computername -Property NumberOfLogicalProcessors).NumberOfLogicalProcessors } },
@{Name = "ComputerName"; Expression = { $_.CSName } }
