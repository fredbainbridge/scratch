﻿#this is the PowerShell code that works interactively in the console

#Start using full cmdlet names and parameters. Start thinking about parameters
Param($Computername)

Get-CimInstance -classname win32_operatingsystem -ComputerName $computername |
Select-Object -Property Caption, Version,
@{Name = "Uptime"; Expression = { (Get-Date) - $_.lastbootuptime } },
@{Name = "MemoryGB"; Expression = { $_.totalvisiblememorysize / 1MB -as [int32] } },
@{Name = "PhysicalProcessors"; Expression = { (Get-CimInstance -classname win32_computersystem -ComputerName $computername -Property NumberOfProcessors).NumberOfProcessors } },
@{Name = "LogicalProcessors"; Expression = { (Get-CimInstance -classname win32_computersystem -ComputerName $computername -Property NumberOfLogicalProcessors).NumberOfLogicalProcessors } },
@{Name = "ComputerName"; Expression = { $_.CSName } }

#this code doesn't have to perfect but it should be functional